function coin_toss() {
    var image = new Array("odd.jpeg", "even.jpeg");
    var random_image = Math.floor(Math.random() * image.length);
    document.getElementById("flip").src = image[random_image];
}